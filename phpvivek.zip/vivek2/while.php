<body>  
	<style>
		div{
			color:red;
			
		}
	</style>
	<center>  
		<div>
			<?php
				$a = 0;
				$b = 5;
				
				echo "while loop".'<br>';
				
				while($a <  $b){
					echo $a.'<br>';
					$a++;
				}
			?>
		</div>
	</center> 
</body>