<?php
	$a = $_POST['a'];
	$b = $_POST['p'];
	
	if($a == 'vivek' && $b == 'dudhat' )
		echo "<font color=green>login</font>";
	else
		echo "<font color=red>error</font>";
?>