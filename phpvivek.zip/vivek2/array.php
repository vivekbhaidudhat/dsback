<?php
	$viv=array(5=>122,'myname'=>'vivek','address'=>array('dis'=>array('amreli','ahemdabad'),'pin'=>222222));
	echo "<pre>";
	print_r($viv);
?>