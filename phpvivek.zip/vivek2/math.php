<?php
	$a = -90;
	$b = 5.49;
	echo abs($a);
	echo round($b).'<br>';
	echo ceil($b).'<br>';
	echo floor($b).'<br>';
	echo rand(100000,999999);
?>