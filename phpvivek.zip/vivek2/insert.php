<?php
	$con = mysqli_connect("localhost","root","","vivek");
	$name = $_POST['v'];
	$email = $_POST['vv'];
	
	$sql="insert into user(name,email) value('$name','$email')";
	
	mysqli_query($con,$sql);
?>