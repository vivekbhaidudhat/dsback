<?php
	$viv=array(array('address'=>array('amreli',365601,array("busdepo",99901))));
	echo "<pre>";
	print_r($viv);
	echo $viv[0]['address'][0];
	echo "<br>";
	echo $viv[0]['address'][1];
	echo "<br>";
	echo $viv[0]['address'][2][0];
	echo "<br>";
	echo $viv[0]['address'][2][1];
?>