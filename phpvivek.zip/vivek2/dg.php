<?php
	$image = imagecreate(200,150);

	$bg_color = imagecolorallocate($image,0,70,2);
	$text_color = imagecolorallocate($image,255,0,0);

	imagestring($image,25,60,60,"vivek",$text_color);

	header("Content-Type: image/png");

	imagepng($image);

	imagedestroy($image);
?>