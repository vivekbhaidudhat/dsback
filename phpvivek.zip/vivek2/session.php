<?php
	session_start();
	$_SESSION['viv']="session";
	
	echo $_SESSION['viv'];
?>