<?php
	$viv=array("user"=>array("name"=>"text","age"=>array("num"=>4)));
	echo json_encode($viv,true);
	$string=json_encode($viv,true);
	$viv=json_decode($string,true);
	echo '<pre>';
	print_r($viv);
?>