<?php
	$b = "local";
	$a="that is globale variablr";
	function viv(){
		global $a;
		echo $a.'<br>';
		
		echo $GLOBALS['b'];
	}
	viv();
?>