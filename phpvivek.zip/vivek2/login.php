<html>
	<body>
		<form action="/vivek2/login2.php" method="post">
			<input type="text" name="a" placeholder="user name">	<br>
			<input type="password" name="p" placeholder="password">	<br>
			<input type="submit"  name="submit">
			</form>
	</body>
</html>