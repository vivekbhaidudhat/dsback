<html>

	<body>
		<form action="/vivek2/min.php" method="post">
			<input type="number" name="a1"> <br>
			<input type="number" name="a2"> <br>
			<input type="number" name="a3"> <br>
			<input type="number" name="a4"> <br>
			<input type="number" name="a5"> <br>
			<input type="submit">
		</form>
	</body>
</html>