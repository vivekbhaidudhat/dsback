<body>
	<style>
	</style>
	<div>
		<?php
			$a = 1;
			$b = 5;
			
			do{
				echo $a.'<br>';
				$a++;
			}while($a <= $b);
		?>
	</div>
</body>