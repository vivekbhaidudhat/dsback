<?php
	echo date('d-m-y').'<br>';
	echo date('D-F-y');
?>