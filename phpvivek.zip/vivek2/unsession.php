<?php
	unset($_SESSION['viv']);
?>