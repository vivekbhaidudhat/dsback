<?php
$con = mysqli_connect("localhost","root","","vivek");

// DELETE (only when id exists)
if(isset($_GET['id'])){
    $id = intval($_GET['id']);
    mysqli_query($con, "DELETE FROM user WHERE id=$id");
}

// FETCH DATA
$data = mysqli_query($con, "SELECT * FROM user");
?>

<table border="1">
<tr>
    <td>id</td>
    <td>name</td>
    <td>email</td>
    <td>action</td>
</tr>

<?php while($row = mysqli_fetch_assoc($data)){ ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td>
        <a href="select.php?id=<?php echo $row['id']; ?>">Delete</a>
    </td>
</tr>
<?php } ?>

</table>