<?php
	$str = "I like PHP programming";			

	echo "Original String: " . $str . "<br>";
	echo "Length: " . strlen($str) . "<br>";

	$newstr = str_replace("PHP", "python", $str);

	echo "After Replace: " . $newstr;
?>