<form action="/vivek2/insert.php" method="post">
	<input type="text" name="v">
	<input type="text" name="vv">
	<input type="submit" value="submit">
</form>