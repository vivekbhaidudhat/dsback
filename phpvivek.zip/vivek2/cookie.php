<?php
	setcookie('hii',"my first cookie",time()+60);
	echo $_COOKIE['hii'];
?>