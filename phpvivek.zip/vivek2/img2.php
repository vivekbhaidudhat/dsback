<?php
	
	echo $_FILES['vi']["name"].'<br>';
	//echo "<pre>";
	//print_r($_FILES['vi']);
	echo $_FILES['vi']["error"].'<br>';
	echo $_FILES['vi']["size"].'<br>';
	echo $_FILES['vi']["tmp_name"].'<br>';
	
	

?>