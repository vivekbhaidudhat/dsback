<?php
	$a = $_POST['viv'];
	$b = $_POST['viv2'];
	
	if(isset($_POST['sum'])){
		echo $a + $b;
	}
	if(isset($_POST['sub'])){
		echo $a - $b;
	}
	if(isset($_POST['mult'])){
		echo $a * $b;
	}
	if(isset($_POST['div'])){
		if($b != 0)
			echo $a / $b;
		else
			echo "don't enter 0";
	}
?>