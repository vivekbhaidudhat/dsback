<form action="/vivek2/img2.php" method="post" enctype="multipart/form-data">
	<input type="file" name="vi">
	<br>
	<input type="submit">
</form>