<html>
	<body> <center>
		<form action="/vivek2/cla2.php" method="post">
			<input type="number" name="viv" placeholder="enter number"><br>
			<input type="number" name="viv2" placeholder="enter number">
			<br>
			<input type="submit" name="sum" value="+">
			<input type="submit" name="sub" value="-">
			<input type="submit" name="mult" value="*">
			<input type="submit" name="div" value="/">
		</form>	</center>
	</body>
</html>