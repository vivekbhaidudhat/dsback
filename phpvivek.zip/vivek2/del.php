<?php
	$id = $_GET['id'];
	
	$con = mysqli_connect("localhost","root","","vivek");
	$sql="delete from user where id=".$id;
	
	$data=mysqli_query($con,$sql);
?>