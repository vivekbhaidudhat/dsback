<?php
	$b1 = $_POST['a1'];
	$b2 = $_POST['a2'];
	$b3 = $_POST['a3'];
	$b4 = $_POST['a4'];
	$b5 = $_POST['a5'];
	
	echo "largest number = ";
	echo max($b1,$b2,$b3,$b4,$b5).'<br>';
	echo "smallest number = ";
	echo min($b1,$b2,$b3,$b4,$b5).'<br>';
?>