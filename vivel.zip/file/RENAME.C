#include<stdio.h>
void main(){
	int v;
	char old[]="rename1.txt";
	char fnew[]="rename2.txt";
	clrscr();
	v=rename(old,fnew);
	if(v==0)
		printf("successfully");
	else
		printf("erroe");

	getch();
}