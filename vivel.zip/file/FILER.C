#include<stdio.h>
#include<conio.h>
void main(){
	FILE *vi;
	vi = fopen("demo.txt","r");
	fprintf(vi,"dudhat vivek");
	fclose(vi);
	getch();
}