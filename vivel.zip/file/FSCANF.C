#include<stdio.h>
#include<conio.h>
void main(){
	FILE *fp;
	int roll;
	char name[25];
	clrscr();
	fp = fopen("bca.txt","r");
	fscanf(fp,"%d %s",&roll,name);
	printf("%d \n %s",roll,name);
	fclose(fp);
	getch();
}