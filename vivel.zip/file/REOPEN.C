#include<stdio.h>
#include<conio.h>
void main(){
	FILE *v;
	clrscr();
	v=freopen("reopen.txt","w+",stdout);
	printf("dudhat \n");
	fclose(v);
	getch();
}