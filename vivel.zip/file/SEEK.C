#include<stdio.h>
#include<conio.h>
void main(){
	FILE *v;
	clrscr();
	v=fopen("seek.txt","r");
	fseek(v,0,SEEK_END);
	printf("%d",ftell(v));
	getch();
}