#include<stdio.h>
#include<conio.h>
#define size 5
void select_sort(int[]);
void main(){
	int a[size],i;
	clrscr();
	for(i=0;i<size;i++){
		printf("enter element : ");
		scanf("%d",&a[i]);
	}
	select_sort(a);
	getch();
}
void select_sort(int arr[]){
	int i,j,t=0;
		for(i=0;i<size;i++){
			for(j=i+1;j<size;j++){
			if(arr[i]>arr[j]{
				t=arr[i];
				arr[i]=arr[j];
				arr[j]=t;
			}
			}
		}
		for (i=0;i<SIZE;i++){
			printf("\n %d",arr[i]);
		}
}
